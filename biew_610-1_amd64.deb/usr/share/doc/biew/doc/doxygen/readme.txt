For building code-navigation documentation you must download and install
DOXYGEN (DOXYGEN is documentation system for C, C++ and IDL).

The latest version of doxygen can be obtained at:
  http://www.stack.nl/~dimitri/doxygen
